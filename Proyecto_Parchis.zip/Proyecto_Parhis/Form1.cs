﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Data.SqlClient;


namespace Proyecto_Parhis
{
    public partial class Menu : Form
    {
        Socket server;
        public Menu()
        {
            InitializeComponent();
            log_contraseña.PasswordChar = '*';
            log_nombre.MaxLength = 20;
            log_contraseña.MaxLength = 20;

        }
        int logged = 0;
        private void Menu_Load(object sender, EventArgs e)
        {
            TablaConectados.ColumnCount = 1;
            TablaConectados.RowCount = 100;
            TablaConectados.ColumnHeadersVisible = false;
            TablaConectados.RowHeadersVisible = false;
            TablaConectados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }
        private void alta_nombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void alta_contraseña_TextChanged(object sender, EventArgs e)
        {

        }

        private void log_nombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void log_contraseña_TextChanged(object sender, EventArgs e)
        {

        }


        private void darse_alta_Click(object sender, EventArgs e)
        {
            string mensaje = "1/" + alta_nombre.Text + "/" + alta_contraseña.Text;
            // Enviamos al servidor el nombre el user y la contraseña
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show(mensaje);

        }

        private void log_Click(object sender, EventArgs e)
        {
            string mensaje = "2/" + log_nombre.Text + "/" + log_contraseña.Text;
            // Enviamos al servidor el nombre el user y la contraseña
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            string mensaje2;
            string[] ms2;
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje2 = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            ms2 = mensaje2.Split('_');
            MessageBox.Show(ms2[0]);
            MuestraConectados(ms2[1]);

        }

        private void Consulta1_Click(object sender, EventArgs e)
        {
            string mensaje = "3/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[100];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show(mensaje);

        }

        private void Consulta2_Click(object sender, EventArgs e)
        {
            string mensaje = "4/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show(mensaje);
        }

        private void TablaConectados_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string mensaje = ("7/" + log_nombre.Text + "/");
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show(mensaje);
        }

        public void MuestraConectados(string conectados)
        {
            int i;
            string[] lista = conectados.Split('/');
            for (i = 0; i < lista.Length - 1; i++)
            {
                TablaConectados.Rows[i].Cells[0].Value = 0;
            }
            for (i = 0; i < lista.Length - 1; i++)
            {
                TablaConectados.Rows[i].Cells[0].Value = lista[i];
            }
        }
        public void DameConectados()
        {
            string mensaje = "5/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            string mensaje2;
            byte[] msg2 = new byte[100];
            server.Receive(msg2);
            mensaje2 = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MuestraConectados(mensaje2);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            IPAddress direc = IPAddress.Parse("192.168.56.101"); //IP A LA QUE NOS VAMOS A CONECTAR
            IPEndPoint ipep = new IPEndPoint(direc, 9050); //Puerto de Shiva 5040-5042
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);
                this.BackColor = Color.Green;
                MessageBox.Show("conectado");

            }
            catch (SocketException)
            {
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
        }

        private void desconectar_Click(object sender, EventArgs e)
        {
            string mensaje = ("0/");

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
            DameConectados();



            //desconexion
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void cerrar_sesion_Click(object sender, EventArgs e)
        {
            string mensaje = ("6/" + log_nombre.Text + "/");
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            string mensaje2;
            byte[] msg2 = new byte[100];
            server.Receive(msg2);
            mensaje2 = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MuestraConectados(mensaje2);
            DameConectados();
        }
    }
}
