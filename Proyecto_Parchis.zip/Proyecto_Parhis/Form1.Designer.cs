﻿

namespace Proyecto_Parhis
{
    partial class Menu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            label1 = new System.Windows.Forms.Label();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            groupBox1 = new System.Windows.Forms.GroupBox();
            cerrar_sesion = new System.Windows.Forms.Button();
            desconectar = new System.Windows.Forms.Button();
            conectar = new System.Windows.Forms.Button();
            TablaConectados = new System.Windows.Forms.DataGridView();
            Consulta2 = new System.Windows.Forms.Button();
            Consulta1 = new System.Windows.Forms.Button();
            log = new System.Windows.Forms.Button();
            darse_alta = new System.Windows.Forms.Button();
            log_contraseña = new System.Windows.Forms.TextBox();
            label8 = new System.Windows.Forms.Label();
            log_nombre = new System.Windows.Forms.TextBox();
            label7 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            alta_contraseña = new System.Windows.Forms.TextBox();
            alta_nombre = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            groupBox2 = new System.Windows.Forms.GroupBox();
            label2 = new System.Windows.Forms.Label();
            timer1 = new System.Windows.Forms.Timer(components);
            button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)TablaConectados).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(15, 31);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(0, 20);
            label1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            pictureBox1.Image = Properties.Resources.parchis__1_;
            pictureBox1.Location = new System.Drawing.Point(507, 16);
            pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(590, 688);
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = System.Drawing.SystemColors.Window;
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(cerrar_sesion);
            groupBox1.Controls.Add(desconectar);
            groupBox1.Controls.Add(conectar);
            groupBox1.Controls.Add(TablaConectados);
            groupBox1.Controls.Add(Consulta2);
            groupBox1.Controls.Add(Consulta1);
            groupBox1.Controls.Add(log);
            groupBox1.Controls.Add(darse_alta);
            groupBox1.Controls.Add(log_contraseña);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(log_nombre);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(alta_contraseña);
            groupBox1.Controls.Add(alta_nombre);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Font = new System.Drawing.Font("Cambria Math", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            groupBox1.Location = new System.Drawing.Point(46, 16);
            groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            groupBox1.Size = new System.Drawing.Size(455, 839);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Menú:";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // cerrar_sesion
            // 
            cerrar_sesion.Font = new System.Drawing.Font("Yu Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            cerrar_sesion.Location = new System.Drawing.Point(283, 341);
            cerrar_sesion.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            cerrar_sesion.Name = "cerrar_sesion";
            cerrar_sesion.Size = new System.Drawing.Size(112, 43);
            cerrar_sesion.TabIndex = 24;
            cerrar_sesion.Text = "Cerrar Sesión";
            cerrar_sesion.UseVisualStyleBackColor = true;
            cerrar_sesion.Click += cerrar_sesion_Click;
            // 
            // desconectar
            // 
            desconectar.Font = new System.Drawing.Font("Yu Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            desconectar.Location = new System.Drawing.Point(317, 107);
            desconectar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            desconectar.Name = "desconectar";
            desconectar.Size = new System.Drawing.Size(112, 31);
            desconectar.TabIndex = 23;
            desconectar.Text = "Desconectar";
            desconectar.UseVisualStyleBackColor = true;
            desconectar.Click += desconectar_Click;
            // 
            // conectar
            // 
            conectar.Font = new System.Drawing.Font("Yu Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            conectar.Location = new System.Drawing.Point(343, 53);
            conectar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            conectar.Name = "conectar";
            conectar.Size = new System.Drawing.Size(86, 31);
            conectar.TabIndex = 22;
            conectar.Text = "Conectar";
            conectar.UseVisualStyleBackColor = true;
            conectar.Click += button1_Click;
            // 
            // TablaConectados
            // 
            TablaConectados.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            TablaConectados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            TablaConectados.Location = new System.Drawing.Point(261, 543);
            TablaConectados.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            TablaConectados.Name = "TablaConectados";
            TablaConectados.RowHeadersWidth = 51;
            TablaConectados.RowTemplate.Height = 25;
            TablaConectados.Size = new System.Drawing.Size(168, 284);
            TablaConectados.TabIndex = 20;
            TablaConectados.CellContentClick += TablaConectados_CellContentClick;
            // 
            // Consulta2
            // 
            Consulta2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            Consulta2.Font = new System.Drawing.Font("Yu Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            Consulta2.Location = new System.Drawing.Point(14, 728);
            Consulta2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            Consulta2.Name = "Consulta2";
            Consulta2.Size = new System.Drawing.Size(215, 64);
            Consulta2.TabIndex = 19;
            Consulta2.Text = "CONSULTA 2";
            Consulta2.UseVisualStyleBackColor = false;
            Consulta2.Click += Consulta2_Click;
            // 
            // Consulta1
            // 
            Consulta1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            Consulta1.Font = new System.Drawing.Font("Yu Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            Consulta1.Location = new System.Drawing.Point(14, 625);
            Consulta1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            Consulta1.Name = "Consulta1";
            Consulta1.Size = new System.Drawing.Size(215, 64);
            Consulta1.TabIndex = 18;
            Consulta1.Text = "CONSULTA 1";
            Consulta1.UseVisualStyleBackColor = false;
            Consulta1.Click += Consulta1_Click;
            // 
            // log
            // 
            log.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            log.Location = new System.Drawing.Point(261, 457);
            log.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            log.Name = "log";
            log.Size = new System.Drawing.Size(95, 39);
            log.TabIndex = 16;
            log.Text = "Log in";
            log.UseVisualStyleBackColor = true;
            log.Click += log_Click;
            // 
            // darse_alta
            // 
            darse_alta.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            darse_alta.Location = new System.Drawing.Point(261, 225);
            darse_alta.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            darse_alta.Name = "darse_alta";
            darse_alta.Size = new System.Drawing.Size(95, 40);
            darse_alta.TabIndex = 15;
            darse_alta.Text = "Enviar";
            darse_alta.UseVisualStyleBackColor = true;
            darse_alta.Click += darse_alta_Click;
            // 
            // log_contraseña
            // 
            log_contraseña.Font = new System.Drawing.Font("Yu Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            log_contraseña.Location = new System.Drawing.Point(114, 484);
            log_contraseña.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            log_contraseña.Name = "log_contraseña";
            log_contraseña.Size = new System.Drawing.Size(114, 38);
            log_contraseña.TabIndex = 14;
            log_contraseña.TextChanged += log_contraseña_TextChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Cambria Math", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(8, 457);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(112, 84);
            label8.TabIndex = 13;
            label8.Text = "Contraseña: ";
            // 
            // log_nombre
            // 
            log_nombre.Font = new System.Drawing.Font("Yu Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            log_nombre.Location = new System.Drawing.Point(114, 413);
            log_nombre.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            log_nombre.Name = "log_nombre";
            log_nombre.Size = new System.Drawing.Size(114, 38);
            log_nombre.TabIndex = 12;
            log_nombre.TextChanged += log_nombre_TextChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Cambria Math", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label7.Location = new System.Drawing.Point(23, 385);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(93, 84);
            label7.TabIndex = 11;
            label7.Text = "Nombre: ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Cambria Math", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(7, 315);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(123, 95);
            label6.TabIndex = 10;
            label6.Text = "- Loguearse";
            // 
            // alta_contraseña
            // 
            alta_contraseña.Font = new System.Drawing.Font("Yu Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            alta_contraseña.Location = new System.Drawing.Point(114, 256);
            alta_contraseña.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            alta_contraseña.Name = "alta_contraseña";
            alta_contraseña.Size = new System.Drawing.Size(114, 38);
            alta_contraseña.TabIndex = 9;
            alta_contraseña.TextChanged += alta_contraseña_TextChanged;
            // 
            // alta_nombre
            // 
            alta_nombre.Font = new System.Drawing.Font("Yu Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            alta_nombre.Location = new System.Drawing.Point(114, 181);
            alta_nombre.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            alta_nombre.Name = "alta_nombre";
            alta_nombre.Size = new System.Drawing.Size(114, 38);
            alta_nombre.TabIndex = 8;
            alta_nombre.TextChanged += alta_nombre_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Cambria Math", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(7, 87);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(147, 95);
            label5.TabIndex = 7;
            label5.Text = "- Darse de alta:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Cambria Math", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(8, 225);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(112, 84);
            label4.TabIndex = 6;
            label4.Text = "Contraseña: ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Cambria Math", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(23, 155);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(90, 84);
            label3.TabIndex = 5;
            label3.Text = "Nombre:";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = System.Drawing.SystemColors.HighlightText;
            groupBox2.Controls.Add(label2);
            groupBox2.Location = new System.Drawing.Point(554, 744);
            groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            groupBox2.Size = new System.Drawing.Size(526, 93);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(193, 25);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(172, 44);
            label2.TabIndex = 0;
            label2.Text = "PARCHIS";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // button1
            // 
            button1.Location = new System.Drawing.Point(335, 145);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(94, 29);
            button1.TabIndex = 25;
            button1.Text = "Cerrar sesión";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // Menu
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1171, 892);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
            Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            Name = "Menu";
            Text = "Menú";
            Load += Menu_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)TablaConectados).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox alta_nombre;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox log_contraseña;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox log_nombre;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox alta_contraseña;
        private System.Windows.Forms.Button log;
        private System.Windows.Forms.Button darse_alta;
        private System.Windows.Forms.Button Consulta2;
        private System.Windows.Forms.Button Consulta1;
        private System.Windows.Forms.DataGridView TablaConectados;
        private System.Windows.Forms.Button conectar;
        private System.Windows.Forms.Button desconectar;
        private System.Windows.Forms.Button cerrar_sesion;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button1;
    }
}

